#!/bin/bash
#SBATCH --job-name=llama3b-sop
#SBATCH --partition=GPU
#SBATCH --gres=gpu:TitanRTX:1
#SBATCH --constraint=compute_75
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=32G
#SBATCH --time=06:00:00
#SBATCH --output=logs/%x-%j.out
#SBATCH --error=logs/%x-%j.err


# Optional: Improve CUDA memory allocation
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

# Run training
python llama3b_qlora_train.py
