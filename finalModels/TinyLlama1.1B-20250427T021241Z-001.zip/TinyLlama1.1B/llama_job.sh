#!/bin/bash
#SBATCH --job-name=tinyllama-sop
#SBATCH --partition=GPU
#SBATCH --gres=gpu:TitanRTX:1
#SBATCH --constraint=compute_75
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=32G
#SBATCH --time=04:00:00
#SBATCH --output=logs/%x-%j.out
#SBATCH --error=logs/%x-%j.err

# (Optional) Clear GPU memory before starting
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

python train.py
