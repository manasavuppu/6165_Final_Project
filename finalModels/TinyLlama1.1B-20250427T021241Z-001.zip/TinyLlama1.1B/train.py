import os
os.environ["TOKENIZERS_PARALLELISM"] = "false"

from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import LoraConfig, get_peft_model
from datasets import DatasetDict, Dataset
import pandas as pd
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

# 1. Load full dataset
df = pd.read_excel("dataset.xlsx").dropna(subset=["cleaned_text"]).copy()
df["text"] = "[SOP] " + df["cleaned_text"].astype(str)

# 2. Train/Val split
train_df = df.sample(frac=0.8, random_state=42)
val_df = df.drop(train_df.index)

train_dataset = Dataset.from_pandas(train_df[["text"]], preserve_index=False)
val_dataset = Dataset.from_pandas(val_df[["text"]], preserve_index=False)
dataset = DatasetDict({"train": train_dataset, "validation": val_dataset})

# 3. Tokenizer
model_id = "TinyLLaMA/TinyLLaMA-1.1B-Chat-v1.0"
tokenizer = AutoTokenizer.from_pretrained(model_id)
tokenizer.pad_token = tokenizer.eos_token

# 4. Tokenize with tail masking
MAX_LEN = 512

def tokenize(batch):
    tokenized = tokenizer(
        batch["text"],
        padding="max_length",
        truncation=True,
        max_length=MAX_LEN
    )

    input_ids = tokenized["input_ids"]
    attention_mask = tokenized["attention_mask"]

    labels = []
    for seq in input_ids:
        masked_seq = [-100] * (MAX_LEN - 100) + seq[-100:]
        #masked_seq = [-100] * (len(seq) - 40) + seq[-40:]
        masked_seq = [tok if tok != tokenizer.pad_token_id else -100 for tok in masked_seq]
        labels.append(masked_seq)

    cleaned = [
        (input_ids[i], labels[i], attention_mask[i])
        for i in range(len(labels)) if any(tok != -100 for tok in labels[i])
    ]

    return {
        "input_ids": [c[0] for c in cleaned],
        "labels": [c[1] for c in cleaned],
        "attention_mask": [c[2] for c in cleaned],
    }

# 5. Apply tokenization
tokenized_train = dataset["train"].map(tokenize, batched=True, remove_columns=["text"])
tokenized_val = dataset["validation"].map(tokenize, batched=True, remove_columns=["text"])

tokenized_train.set_format("torch")
tokenized_val.set_format("torch")

train_loader = DataLoader(tokenized_train, batch_size=2, shuffle=True)
val_loader = DataLoader(tokenized_val, batch_size=2)

# 6. Load model
model = AutoModelForCausalLM.from_pretrained(
    model_id, torch_dtype=torch.float32, device_map="auto"
)

lora_config = LoraConfig(
    r=8,
    lora_alpha=32,
    target_modules=["q_proj", "v_proj"],
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM",
)
model = get_peft_model(model, lora_config)
model.train()

# 7. Optimizer
optimizer = torch.optim.AdamW(model.parameters(), lr=1e-5)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

# 8. Training loop
EPOCHS = 5
print(" Starting training...")
for epoch in range(EPOCHS):
    total_loss = 0
    valid_steps = 0

    for step, batch in enumerate(tqdm(train_loader, desc=f"Epoch {epoch+1}")):
        batch = {k: v.to(device) for k, v in batch.items()}
        outputs = model(**batch)
        loss = outputs.loss

        if torch.isnan(loss):
            print(f" NaN loss at step {step}, skipping.")
            continue

        loss.backward()
        optimizer.step()
        optimizer.zero_grad()

        total_loss += loss.item()
        valid_steps += 1

    avg_loss = total_loss / max(valid_steps, 1)
    print(f" Epoch {epoch+1} complete | Avg Loss: {avg_loss:.4f}")

# 9. Save
save_dir = "tinyllama-sop-lora"
os.makedirs(save_dir, exist_ok=True)
model.save_pretrained(save_dir)
tokenizer.save_pretrained(save_dir)
print(f" Model saved to '{save_dir}'")
