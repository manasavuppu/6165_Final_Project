#!/usr/bin/env python3
import os
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel
from datetime import datetime

# === Config ===
BASE_MODEL = "meta-llama/Llama-3.2-3B"
LORA_PATH = "llama3.2-3b-lora-fixed"
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
MAX_NEW_TOKENS = 1500

# === Load Tokenizer & Model ===
print(" Loading model and LoRA adapter...")
tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL)
model = AutoModelForCausalLM.from_pretrained(
    BASE_MODEL, 
    torch_dtype=torch.float16, 
    device_map="auto"
)
model = PeftModel.from_pretrained(model, LORA_PATH)
model.eval().to(DEVICE)

# === Load Few-Shot Examples ===
few_shot_path = "few_shot_examples.txt"
if not os.path.exists(few_shot_path):
    print(f" Few-shot example file not found: {few_shot_path}")
    print(" Please create a 'few_shot_examples.txt' file with Prompt → Response pairs.")
    exit()

with open(few_shot_path, "r") as f:
    few_shot_text = f.read().strip()

print("\n Ready! Generate a Statement of Purpose (SOP) using few-shot learning.")

# === Generation Loop ---
while True:
    print("\n Paste your NEW custom SOP prompt below. End with an empty line:")
    lines = []
    while True:
        line = input()
        if line.strip().lower() in ["exit", "quit"]:
            print(" Exiting.")
            exit()
        if line.strip() == "":
            break
        lines.append(line)
    user_custom_prompt = "\n".join(lines).strip()

    if not user_custom_prompt:
        print(" Prompt was empty. Try again.")
        continue

    # Build prompt with few-shot examples.
    prompt_text = (
        few_shot_text.strip() + "\n\n"
        f"Prompt: {user_custom_prompt}\n\n"
        "Response:\n"
    )

    inputs = tokenizer(prompt_text, return_tensors="pt").to(DEVICE)
    prompt_len = inputs["input_ids"].shape[-1]

    print(" Generating SOP (please wait)...")
    with torch.no_grad():
        output = model.generate(
            **inputs,
            max_new_tokens=MAX_NEW_TOKENS,
            do_sample=True,
            temperature=0.4,    # taking a conservative output.
            top_p=0.8,          # Narrow probability mass.
            top_k=40,           # Limited candidate tokens.
            repetition_penalty=1.2,
            no_repeat_ngram_size=3,
            pad_token_id=tokenizer.eos_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )

    generated_tokens = output[0][prompt_len:]
    decoded = tokenizer.decode(generated_tokens, skip_special_tokens=True).strip()
    word_count = len(decoded.split())

    print("\n===  Generated SOP ===\n")
    print(decoded)
    print(f"\n Word count: {word_count} | Tokens: {len(generated_tokens)}")

    save = input("\n Save this SOP? (y/n): ").strip().lower()
    if save == "y":
        tag = "custom"
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_name = f"sop_{tag}_{ts}.txt"
        os.makedirs("outputs", exist_ok=True)
        with open(f"outputs/{file_name}", "w") as f:
            f.write("=== Prompt Used ===\n")
            f.write(prompt_text + "\n\n")
            f.write("=== Generated SOP ===\n")
            f.write(decoded + "\n")
            f.write(f"\nWord count: {word_count}\n")
        print(f" Saved to: outputs/{file_name}")

    input("\n Press Enter to generate another SOP...")
