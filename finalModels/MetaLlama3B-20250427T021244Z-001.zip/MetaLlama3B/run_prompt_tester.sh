#!/bin/bash
# Launch an interactive GPU session and run the prompt tester

srun --partition=GPU \
     --gres=gpu:TitanRTX:1 \
     --constraint=compute_75 \
     --cpus-per-task=4 \
     --mem=32G \
     --time=01:30:00 \
     --pty bash -c "
        module load anaconda3/2023.09 && \
        source activate llama3b-qlora-env && \
        python prompt_testing_assistant.py
     "