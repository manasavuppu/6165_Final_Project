#!/usr/bin/env python3
import os
import torch
import pandas as pd
from tqdm import tqdm
from datasets import Dataset, DatasetDict
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import LoraConfig, get_peft_model
from torch.utils.data import DataLoader
from torch.cuda.amp import autocast, GradScaler
from torch.utils.tensorboard import SummaryWriter

# === Config ===
os.environ["TOKENIZERS_PARALLELISM"] = "false"
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "max_split_size_mb:64"

MODEL_ID = "meta-llama/Llama-3.2-3B"
OUTPUT_DIR = "llama3.2-3b-lora-fixed"
MAX_LEN = 2048
BATCH_SIZE = 1
EPOCHS = 3
LR = 5e-7
GRAD_ACCUM_STEPS = 4

writer = SummaryWriter(log_dir="logs")

# === Load and preprocess dataset ===
df = pd.read_excel("dataset_with_prompts.xlsx").dropna(subset=["text"]).copy()

# Optional filter: only long SOPs
df["word_count"] = df["cleaned_text"].str.split().str.len()
df = df[df["word_count"] >= 800].copy()

train_df = df.sample(frac=0.8, random_state=42)
val_df = df.drop(train_df.index)

dataset = DatasetDict({
    "train": Dataset.from_pandas(train_df[["text"]]),
    "validation": Dataset.from_pandas(val_df[["text"]])
})

# === Tokenizer ===
tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
tokenizer.pad_token = tokenizer.eos_token
MAX_TOKEN_ID = len(tokenizer) - 1
print(f"Vocab size: {MAX_TOKEN_ID}")

def tokenize(batch):
    out = tokenizer(
        batch["text"],
        padding="longest",          # dynamic padding
        truncation=True,
        max_length=MAX_LEN,
    )
    input_ids, labels, attention_mask = [], [], []
    for i, seq in enumerate(out["input_ids"]):
        clamped = [min(tok, MAX_TOKEN_ID) for tok in seq]
        label = [tok if tok != tokenizer.pad_token_id else -100 for tok in clamped]
        if sum(l != -100 for l in label) > 10:
            input_ids.append(clamped)
            labels.append(label)
            attention_mask.append(out["attention_mask"][i])
    return {"input_ids": input_ids, "attention_mask": attention_mask, "labels": labels}

tokenized = {
    split: dataset[split].map(tokenize, batched=True, remove_columns=["text"], load_from_cache_file=False)
    for split in ["train", "validation"]
}
for split in tokenized:
    tokenized[split].set_format("torch")

# === Load base model ===
model = AutoModelForCausalLM.from_pretrained(
    MODEL_ID,
    device_map="auto"
)
model.config.use_flash_attention_2 = False
model.config._attn_implementation = "eager"
model.config.use_cache = False

# === Apply LoRA ===
lora_config = LoraConfig(
    r=8,
    lora_alpha=16,
    lora_dropout=0.1,
    bias="none",
    target_modules=["q_proj", "v_proj"],
    task_type="CAUSAL_LM"
)
model = get_peft_model(model, lora_config)
model.gradient_checkpointing_enable()
model.enable_input_require_grads()
model.print_trainable_parameters()
model.train()

# === Optimizer and AMP ===
optimizer = torch.optim.AdamW(model.parameters(), lr=LR)
scaler = GradScaler()
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

train_loader = DataLoader(tokenized["train"], batch_size=BATCH_SIZE, shuffle=True)
val_loader = DataLoader(tokenized["validation"], batch_size=BATCH_SIZE, shuffle=False)

def evaluate(model, dataloader, device, max_token_id):
    model.eval()
    total_loss, steps = 0.0, 0
    with torch.no_grad():
        for batch in dataloader:
            batch = {k: v.to(device) for k, v in batch.items()}
            batch["input_ids"] = batch["input_ids"].clamp(0, max_token_id)
            with autocast(dtype=torch.float16):
                outputs = model(**batch)
                loss = outputs.loss
            total_loss += loss.item()
            steps += 1
    model.train()
    return total_loss / steps if steps > 0 else float('inf')

# === Training loop ===
global_step = 0
print("\n Training Started...\n")

try:
    for epoch in range(EPOCHS):
        total_loss, valid_steps = 0, 0
        model.train()
        optimizer.zero_grad()

        for step, batch in enumerate(tqdm(train_loader, desc=f"Epoch {epoch+1}")):
            batch = {k: v.to(device) for k, v in batch.items()}
            batch["input_ids"] = batch["input_ids"].clamp(0, MAX_TOKEN_ID)

            if (batch["labels"] != -100).sum() == 0:
                continue

            with autocast(dtype=torch.float16):
                outputs = model(**batch)
                loss = outputs.loss

            if torch.isnan(loss) or torch.isinf(loss):
                print(f" NaN or Inf loss at step {step}, skipping.")
                continue

            scaler.scale(loss).backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)

            if (step + 1) % GRAD_ACCUM_STEPS == 0:
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad()
                torch.cuda.empty_cache()

            total_loss += loss.item()
            valid_steps += 1
            global_step += 1

            if global_step % 10 == 0:
                writer.add_scalar("Train/Loss", loss.item(), global_step)
            if step % 10 == 0:
                print(f" Step {step} | Loss: {loss.item():.4f}")

        avg_train_loss = total_loss / max(valid_steps, 1)
        avg_val_loss = evaluate(model, val_loader, device, MAX_TOKEN_ID)
        writer.add_scalar("Epoch/Train_Loss", avg_train_loss, epoch)
        writer.add_scalar("Epoch/Val_Loss", avg_val_loss, epoch)

        print(f"\n Epoch {epoch+1} complete | Train Loss: {avg_train_loss:.4f} | Val Loss: {avg_val_loss:.4f}\n")

except KeyboardInterrupt:
    print("\n Training interrupted. Saving model...")

# === Save final model ===
os.makedirs(OUTPUT_DIR, exist_ok=True)
model.save_pretrained(OUTPUT_DIR)
tokenizer.save_pretrained(OUTPUT_DIR)
print(f" Model saved to: {OUTPUT_DIR}")
writer.close()
